
//  ViewController.m
//  Akash
//
//  Created by Placement on 9/20/17.
//  Copyright © 2017 NIET. All rights reserved.
//

#import "ViewController.h"
#import "SecViewController.h"
#define xOffset 10.0f
#define yOffset 20.0f
#define componentHeight 50.0f

@interface ViewController ()

@end

@implementation ViewController
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
}

- (void)viewDidLoad {
  [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor grayColor]];
    // Do any additional setup after loading the view, typically from a nib.
    
    CGFloat componentWidth = self.view.frame.size.width-(xOffset *2);
    CGFloat componentHt = 30.0f;
    CGFloat scrollHt=yOffset;
    
    scrollHt = scrollHt+componentHt+yOffset;
    
    UITextField *firstNametextField = [[UITextField alloc]init];
    [firstNametextField setFrame:CGRectMake(xOffset, scrollHt, componentWidth, componentHt)];
    [firstNametextField setBorderStyle:UITextBorderStyleRoundedRect];
    [firstNametextField setPlaceholder:@"First name"];
    [scroller addSubview:firstNametextField];
    
    scrollHt = scrollHt+componentHt+yOffset;
    
    UITextField *lastNametextField = [[UITextField alloc]init];
    [lastNametextField setFrame:CGRectMake(xOffset, scrollHt, componentWidth, componentHt)];
    [lastNametextField setBorderStyle:UITextBorderStyleRoundedRect];
    [lastNametextField setPlaceholder:@"Last name"];
    [scroller addSubview:lastNametextField];
    
    scrollHt = scrollHt+componentHt+yOffset;
    
    
    UITextField *rollNametextField = [[UITextField alloc]init];
    [rollNametextField setFrame:CGRectMake(xOffset, scrollHt, componentWidth, componentHt)];
    [rollNametextField  setBorderStyle:UITextBorderStyleRoundedRect];
    [rollNametextField setPlaceholder:@"Year"];
    [scroller addSubview:rollNametextField];
    
    scrollHt = scrollHt+componentHt+yOffset;
    
    UITextField *emailNametextField = [[UITextField alloc]init];
    [emailNametextField setFrame:CGRectMake(xOffset, scrollHt, componentWidth, componentHt)];
    [emailNametextField setBorderStyle:UITextBorderStyleRoundedRect];
    [emailNametextField setPlaceholder:@"Email"];
    [scroller addSubview:emailNametextField];
    
    scrollHt = scrollHt+componentHt+yOffset;
    
    UITextField *dobNametextField = [[UITextField alloc]init];
    [dobNametextField setFrame:CGRectMake(xOffset, scrollHt, componentWidth, componentHt)];
    [dobNametextField setBorderStyle:UITextBorderStyleRoundedRect];
    [dobNametextField setPlaceholder:@"Date of Birth"];
    [scroller addSubview:dobNametextField];
    
    scrollHt = scrollHt+componentHt+yOffset;
    
    UITextField *highSchoolNametextField = [[UITextField alloc]init];
    [highSchoolNametextField setFrame:CGRectMake(xOffset, scrollHt, componentWidth, componentHt)];
    [highSchoolNametextField setBorderStyle:UITextBorderStyleRoundedRect];
    [highSchoolNametextField setPlaceholder:@"High School Percentage"];
    [scroller addSubview:highSchoolNametextField];
    
    scrollHt = scrollHt+componentHt+yOffset;
    
    UITextField *intertextField = [[UITextField alloc]init];
    [intertextField setFrame:CGRectMake(xOffset, scrollHt, componentWidth, componentHt)];
    [intertextField setBorderStyle:UITextBorderStyleRoundedRect];
    [intertextField setPlaceholder:@"Intermidiate percentage"];
    [scroller addSubview:intertextField];
    
    scrollHt = scrollHt+componentHt+yOffset;
    
    UIButton *submitButton = [[UIButton alloc]initWithFrame:CGRectMake(xOffset, scrollHt, componentWidth, componentHt)];
    [submitButton setTitle:@"Submit" forState:UIControlStateNormal];
    [submitButton addTarget:self action:@selector(clickAction:)forControlEvents:UIControlEventTouchUpInside] ;
    [submitButton setTintColor:[UIColor blueColor]];
    [submitButton setBackgroundColor:[UIColor blueColor]];
    [scroller addSubview:submitButton];
    
    scrollHt = scrollHt+componentHt+yOffset;
    
}

-(IBAction)clickAction:(id)sender{
  SecViewController *secviewcontroller = [[SecViewController alloc]initWithNibName:@"SecViewController" bundle:nil];
  [self.navigationController pushViewController:secviewcontroller animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
     

     
