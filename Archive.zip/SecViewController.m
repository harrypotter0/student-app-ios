//
//  SecViewController.m
//  Akash
//
//  Created by Placement on 9/20/17.
//  Copyright © 2017 NIET. All rights reserved.
//

#import "SecViewController.h"
//#define xOffset 10.0f
//#define yOffset 20.0f
//#define componentHeight 50.0f

@interface SecViewController ()

@end

@implementation SecViewController
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return 1;
}

UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];

/*
 *   If the cell is nil it means no cell was available for reuse and that we should
 *   create a new one.
 */
if (cell == nil) {
    
    /*
     *   Actually create a new cell (with an identifier so that it can be dequeued).
     */
    
    cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"MyIdentifier"] autorelease];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
}

/*
 *   Now that we have a cell we can configure it to display the data corresponding to
 *   this row/section
 */

NSDictionary *item = (NSDictionary *)[self.content objectAtIndex:indexPath.row];
cell.textLabel.text = [item objectForKey:@"mainTitleKey"];
cell.detailTextLabel.text = [item objectForKey:@"secondaryTitleKey"];
NSString *path = [[NSBundle mainBundle] pathForResource:[item objectForKey:@"imageKey"] ofType:@"png"];
UIImage *theImage = [UIImage imageWithContentsOfFile:path];
cell.imageView.image = theImage;

/* Now that the cell is configured we return it to the table view so that it can display it */

return cell;




- (void)viewDidLoad {
    [super viewDidLoad];
    /*[self.view setBackgroundColor:[UIColor greenColor]];
    // Do any additional setup after loading the view from its nib.
    CGFloat componentWidth = self.view.frame.size.width-(xOffset *2);
    CGFloat componentHt = 30.0f;
    CGFloat scrollHt=yOffset;
    
    scrollHt=scrollHt+componentHt+yOffset;
    
    UILabel *myLabel = [[UILabel alloc]init];
    [myLabel setFrame:(CGRectMake(xOffset, scrollHt, componentWidth, componentHeight))];
    [myLabel setBackgroundColor:[UIColor greenColor]];
    [myLabel setText:@"Hello"];
    [self.view addSubview:myLabel];
    
    scrollHt=scrollHt+componentHt+yOffset;
    
    UILabel *my1Label = [[UILabel alloc]init];
    [my1Label setFrame:(CGRectMake(xOffset, scrollHt, componentWidth, componentHeight))];
    [my1Label setBackgroundColor:[UIColor greenColor]];
    [my1Label setText:@"lulu"];
    
    
    [self.view addSubview:my1Label];
    scrollHt=scrollHt+componentHt+yOffset;
    
    UILabel *my2Label = [[UILabel alloc]init];
    [my2Label setFrame:(CGRectMake(xOffset, scrollHt, componentWidth, componentHeight))];
    [my2Label setBackgroundColor:[UIColor blueColor]];
    [my2Label setText:@"Aakash Gandpal"];
    
    
    [self.view addSubview:my2Label];*/
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end